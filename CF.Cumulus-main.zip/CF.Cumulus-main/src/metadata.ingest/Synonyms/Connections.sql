CREATE SYNONYM [ingest].[Connections] 
FOR [common].[Connections];