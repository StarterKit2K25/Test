CREATE SYNONYM [ingest].[ComputeConnections] 
FOR [common].[ComputeConnections];