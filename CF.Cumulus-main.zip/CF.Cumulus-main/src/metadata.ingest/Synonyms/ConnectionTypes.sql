CREATE SYNONYM [ingest].[ConnectionsTypes] 
FOR [common].[ConnectionsTypes];