﻿SELECT * FROM [control].[BatchExecution]

SELECT * FROM [control].[CurrentExecution]

SELECT * FROM [procfwkReporting].[CurrentExecutionSummary]

SELECT * FROM [control].[CurrentProperties]

SELECT * FROM [control].[Batches]

SELECT * FROM [control].[BatchStageLink]

SELECT * FROM [control].[Orchestrators]

SELECT * FROM [control].[Stages]

SELECT * FROM [control].[Pipelines]

--SELECT * FROM [control].[PipelineParameters]

SELECT * FROM [control].[ExecutionLog]

SELECT * FROM [control].[ErrorLog]

--SELECT * FROM [dbo].[ServicePrincipals]