﻿EXEC [procfwkHelpers].[SetDefaultBatches];
EXEC [procfwkHelpers].[SetDefaultStages];
EXEC [procfwkHelpers].[SetDefaultBatchStageLink];