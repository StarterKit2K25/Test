﻿EXEC [procfwkHelpers].[SetDefaultTenant];
EXEC [procfwkHelpers].[SetDefaultSubscription];
EXEC [procfwkHelpers].[SetDefaultOrchestrators];