CREATE SYNONYM [transform].[ComputeConnections] 
FOR [common].[ComputeConnections];