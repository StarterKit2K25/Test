CREATE SYNONYM [transform].[Connections] 
FOR [common].[Connections];