CREATE SYNONYM [transform].[ConnectionsTypes] 
FOR [common].[ConnectionsTypes];