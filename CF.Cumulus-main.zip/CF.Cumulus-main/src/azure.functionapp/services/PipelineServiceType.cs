﻿namespace cloudformations.cumulus.services
{
    public enum PipelineServiceType
    {
        ADF, SYN, FAB
    }
}