﻿namespace cloudformations.cumulus.returns
{
    public class PipelineDescription
    {
        public string? PipelineExists { get; set; }
        public string? PipelineName { get; set; }
        public string? PipelineId { get; set; }
        public string? PipelineType { get; set; }
        public int? ActivityCount { get; set; }
    }
}