# Databricks notebook source
strSQL = """
    SELECT 1 AS Dummy
"""

# COMMAND ----------

dbutils.notebook.exit(strSQL)
